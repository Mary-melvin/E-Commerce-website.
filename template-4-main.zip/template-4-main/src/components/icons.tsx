import React from 'react'
import Image from 'next/image'
export default function Icons() {
  return (
    <div>
       <div className="mt-2 mb-2 h-4">
    <Image src={"/image 1174.png"} alt={"subscribeBanner"} height={100} width={800}/>
  </div>
    </div>
  )
}
