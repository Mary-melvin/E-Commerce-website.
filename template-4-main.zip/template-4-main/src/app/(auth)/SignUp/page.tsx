import React from 'react'

export default function SignUp() {
  return (
    <div>
      
    </div>
  )
}
