import React from 'react'

export default function OrderCompleted() {
  return (
    <div>
      
    </div>
  )
}
