import React from 'react'

export default function WishList() {
  return (
    <div>
      
    </div>
  )
}

