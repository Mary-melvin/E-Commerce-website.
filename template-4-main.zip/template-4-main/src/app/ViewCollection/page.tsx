import React from 'react'

export default function ViewCollection() {
  return (
    <div>
      
    </div>
  )
}
